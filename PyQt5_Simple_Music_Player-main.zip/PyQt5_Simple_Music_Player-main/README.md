# PyQt5 Simple Music Player
 A simple but functional music player with PyQt5.
Subscribe to [Tommy's Codebase](https://www.youtube.com/@tommys_codebase) on  YouTube for more projects like this.
